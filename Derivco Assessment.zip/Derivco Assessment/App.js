        const fs = require('fs')
        var parse = require('csv-parse')
        const createCsvWriter = require('csv-writer').createObjectCsvWriter;

        const csvWriter = createCsvWriter({
            path: 'output.txt',
            header: [
              {id: 'name', title: 'Name'},
            ]
          });
                
        // "use strict";
        //global variables 
        let count = 0;
        let resultNumber = "";
        let reducedChar = "";
        let processedCharacters = [];
        let New_full_Array = [];
        let Name1 = "", Name2 = "";
        //let isMatch_Result = isMatch(Name1.replace(/[^a-zA-Z]/g, ""), Name2.replace(/[^a-zA-Z]/g, ""));

        let FirstHalf = [];
        let SecondHalf = [];

        let Sum = "";
        let getMatch = [];
        let OddorEven_len;
        let newLength;
        let input = "Read_Name.csv";
        let writeToFile = "";
        

        const readCSV = (input) => {
            fs.readFile(input, function (err, fileData) {
                parse(fileData, {columns: false, trim: true}, function(err, rows) {
                  let rowsCopy = rows;
                  rowsCopy = rowsCopy.shift();
                  rows = rows.filter(row => row != rowsCopy);
                  sortData(rows);
                });
              });
        }

        function sortData(array2D){
            let sortedData = { 
                males: [],
                females: []
            }
            array2D.forEach(element => {
                if(element[1] == 'f'){
                    if(!sortedData.females.includes(element[0])){
                        sortedData.females.push(element[0])
                    }
                }else {
                    if(!sortedData.males.includes(element[0])){
                        sortedData.males.push(element[0])
                    }
                }
            });
            sortedData.males.forEach((male, i) => {
                sortedData.females.forEach((female, index) => {
                    isMatch(male.replace(/[^a-zA-Z]/g, ""), female.replace(/[^a-zA-Z]/g, ""));
                });
            });
            //  sortedData.males.forEach((male, i) => {
            //     sortedData.females.forEach((female, index) => {
            //        //isMatch(male, female); 
            //        let match = isMatch(male, female);
            //        let reduce = reduceChar(match);
                   
            //        //reduceChar(isMatch(male, female));
            //     });
            //  });
        }


        function isMatch(name1, name2){
            Name1 = name1;
            Name2 = name2;
            var One_String = (name1.toLowerCase() + "matches" + name2.toLowerCase()).replace(" ", "");
            for (let i = 0; i < One_String.length; i++) {
                count = 0;
                for (let comparedIndex = 0; comparedIndex < One_String.length; comparedIndex++) {
                    if (!processedCharacters.includes(One_String[i])) {
                        if (One_String[i] == One_String[comparedIndex]) {
                            count++;
                        }
                    }       
                }
                resultNumber += count;
                processedCharacters.push(One_String[i]); 
            }
            //remove 0 char 
            for (let i = 0; i < resultNumber.length; i++) {
                if (resultNumber[i] == "0") {
                    resultNumber = resultNumber.replace(resultNumber[i], "");
                }
            }
            
            reduceChar(resultNumber);
        };

        function reduceChar(isMatch_Result) {
            getMatch = isMatch_Result.toString().split(""); 
            OddorEven_len = getMatch.length % 2; 
            Sum = "";
            reducedChar = "";
            FirstHalf.length = 0;
            SecondHalf.length = 0;
            New_full_Array.length = 0;
            let getMidValue = "";

                // if OddorEven == 1 -> there is a remainder else if 0 -> even 
 
            if (OddorEven_len == 1) {
                     
                    let getNew_len = (getMatch.length / 2).toString();
                    getNew_len = parseFloat(getNew_len.substring(0, getNew_len.indexOf(".")));
                    getMidValue = getMatch[getNew_len]; // to be added at end

                    //split into two arrays 
                    for (let i = 0; i < getNew_len; i++) {
                        FirstHalf.push(getMatch[i]);
                    }

                    for (let i = getNew_len + 1; i < getMatch.length; i++) {
                        SecondHalf.push(getMatch[i]);
                    }

                    //Make 1 even array 
                    New_full_Array = FirstHalf.concat(SecondHalf);
                    let i = New_full_Array.length;

                    do {
                        let Current_First_Index = 0;
                        let Current_Last_Index = 0;

                        Current_First_Index = parseFloat(New_full_Array.shift());
                        Current_Last_Index = parseFloat(New_full_Array.pop());

                        Sum += Current_First_Index + Current_Last_Index;
                        i = i - 2;
                    }
                    while (i > 0)
                    Sum += getMidValue;

                    reducedChar += Sum;
                }
            else if (OddorEven_len == 0) {
                    let i = getMatch.length;
                    do {
                        let Current_First_Index = 0;
                        let Current_Last_Index = 0;

                        Current_First_Index = parseFloat(getMatch.shift());
                        Current_Last_Index = parseFloat(getMatch.pop());

                        Sum += Current_First_Index + Current_Last_Index;
                        i = i - 2;
                    }
                    while (i > 0)

                    reducedChar += Sum;
            }

            isMatch_Result = reducedChar;
            newLength = isMatch_Result.length;
            
            //Recursive approach
                if (newLength <= 2) {
                    return;
                }
                else {
                    reduceChar(isMatch_Result);
                }

                Final_Result(reducedChar, Name1, Name2);
        };

        function Final_Result(perc, Name1, Name2) {
            let percentage = perc;
            let final_string = "";
            if (percentage >= 80) {
                final_string = Name1.replace(/[^a-zA-Z]/g, "") + " " + "matches" + " " + Name2.replace(/[^a-zA-Z]/g, "") + " " + percentage.toString() + "%," + " good match" + "\n"
                writeToFile += final_string;
                fs.writeFile('Output.txt', writeToFile, (err) => {
                    if (err) throw err;
                });

            }
            else {
                final_string = Name1.replace(/[^a-zA-Z]/g, "") + " " + "matches" + " " + Name2.replace(/[^a-zA-Z]/g, "") + " " + percentage.toString() + "%" + "\n"
                writeToFile += final_string;
                fs.writeFile('Output.txt', writeToFile, (err) => {
                    if (err) throw err;
                });
            }
            console.log(final_string);

        };

        readCSV(input);



